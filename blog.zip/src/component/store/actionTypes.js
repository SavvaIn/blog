export const SET_LOGGED = 'SET_LOGGED';
export const SET_USER = 'SET_USER';
export const SET_ERROR = 'SET_ERROR';
